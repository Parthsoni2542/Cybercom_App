export const LOGIN = 'Login';
export const EDIT_PROFILE="EditProfileScreen";
export const UPCOMINGS_TAB = 'Upcomings';
export const HISTORY_TAB = 'History';
export const APPOINTMENT = 'Evulation';